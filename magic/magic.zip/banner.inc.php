<div style="width: 20%; float: left;"><a href="index.php"><img src="inc/logo-white.jpg" width="350px" height="100px"></a></div>
